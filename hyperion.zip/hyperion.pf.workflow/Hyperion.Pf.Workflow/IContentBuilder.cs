namespace Hyperion.Pf.Workflow
{
    /// <summary>
    /// 
    /// </summary>
    public interface IContentBuilder
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        Content Build();
    }
}
