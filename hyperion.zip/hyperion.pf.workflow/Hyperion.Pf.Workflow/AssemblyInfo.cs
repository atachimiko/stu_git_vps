using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Hyperion.Pf.Workflow.Tests")]